const firstload = () => {
  showBySearch();
  checkAuth();
};

//funtion of showing result by search
const showBySearch = () => {
  const searchInput = document.getElementById("search-input");
  const url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${searchInput.value}`;
  fetch(url)
    .then((res) => res.json())
    .then((data) => {
      if (data.meals) {
        const mealItem = data.meals;
        getMealDiv(mealItem);
      } else {
        const collectionOfMeals = document.getElementById("meals-collection");
        collectionOfMeals.innerHTML = `<h1 class="text-danger p-2">No Result Found !!</h1>`;
        const searchInput = document.getElementById("search-input");
        searchInput.value = "";
      }
    })
    .catch((error) => {
      const collectionOfMeals = document.getElementById("meals-collection");
      collectionOfMeals.innerHTML = `<h1 class="text-danger p-2">Sorry failed to load data !!</h1>`;
      const searchInput = document.getElementById("search-input");
      searchInput.value = "";
    });
};
const getMealDiv = (mealItem) => {
  const collectionOfMeals = document.getElementById("meals-collection");
  collectionOfMeals.innerHTML = "";
  mealItem.forEach((meal) => {
    const mealDiv = document.createElement("div");
    mealDiv.className = "col-lg-3 col-md-6 col-sm-12";
    mealDiv.innerHTML = `
            <div class="card hover:scale-110 shadow-md cursor-pointer transition" onClick="detailsPopUp(${meal.idMeal})">
                <img src="${meal.strMealThumb}" alt="${meal.strMeal}">
            <div class="card-body">
               <h3 class="card-title text-xl">${meal.strMeal}</h3>
            </div>
             </div>
            `;
    collectionOfMeals.appendChild(mealDiv);
  });
};

// details popUp
const detailsPopUp = (mealId, close) => {
  if (close) {
    document.getElementById("popUpId").classList.remove("active");
    return;
  }
  document.getElementById("popUpId").classList.toggle("active");
  const url = `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${mealId}`;
  fetch(url)
    .then((res) => res.json())
    .then((data) => {
      const meal = data.meals[0];
      const displayDetails = document.getElementById("popUp-Content-Id");
      displayDetails.innerHTML = `
            <button class="close-btn" onclick="detailsPopUp()"><i class="far fa-times-circle"></i></button>
            <div class="card p-3">
                <img src="${meal.strMealThumb}">
                <h1 class="card-title p-2" >${meal.strMeal}</h1>
                <h5 class="p-2">Ingredients</h5>
            <div class="card-boby">
                <ul class="p-2">
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure1} ${meal.strIngredient1}</li>
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure2} ${meal.strIngredient2}</li>
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure3} ${meal.strIngredient3}</li>
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure4} ${meal.strIngredient4}</li>
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure5} ${meal.strIngredient5}</li>
                    <li><i class="fas fa-check-square"></i> ${meal.strMeasure6} ${meal.strIngredient6}</li>
                </ul>
            </div>
            <a class="card-footer bg-transparent text-center" href = "${meal.strYoutube}" target = "_blank">Watch the recipe video</a>
            </div>
            `;
    })
    .catch((error) => {
      const errorPopuUp = document.getElementById("popUp-Content-Id");
      errorPopuUp.innerHTML = `<div class"p-3">
            <button class="close-btn" onclick="detailsPopUp()"><i class="far fa-times-circle"></i></button>
            <h2 class="text-danger text-center pt-5">Sorry failed to load data !!</h2>
            <h5 class="text-danger text-center pb-5">Please try again after some time</h5>
            </div>
            `;
    });
};

document.addEventListener("keydown", (event) => {
  if (event.key == "Enter") {
    event.preventDefault();
    showBySearch();
  }
  if (event.key == "Escape") {
    event.preventDefault();
    detailsPopUp("w", true);
  }
});

const showAuth = () => {
  document.getElementById("auth").toggleAttribute("data-active");
};

const showSignup = () => {
  document.getElementById("login").toggleAttribute("data-active");
  document.getElementById("signup").toggleAttribute("data-active");
};

const showLogin = () => {
  document.getElementById("signup").toggleAttribute("data-active");
  document.getElementById("login").toggleAttribute("data-active");
};

const checkAuth = () => {
  const cookies = document.cookie;
  if (cookies.includes("auth") && cookies.includes("true")) {
    const email = cookies.split(";")[0].split("=")[1];
    document.getElementById("authVerify").innerHTML = `
      <button onclick=showProfile()>
        <i
          class="fa-solid fa-user text-4xl text-orange-600 hover:!text-black hover:scale-105 transition-all transform-gpu"></i>
      </button>
      <div id="profile" class="data-[active]:flex hidden fixed top-20 bg-white rounded-lg p-3 flex-col justify-start items-center">
        <h1>${email}</h1>
        <hr class="w-full my-3 bg-black border-2" />
        <button class="py-2 rounded-lg w-full bg-orange-500 text-white hover:scale-105 hover:!text-black" onclick="logout()">Logout</h1>
      </div>`;
  } else {
    document.getElementById("authVerify").innerHTML = `
      <button onclick="showAuth()"
        class="text-lg bg-orange-600 rounded-lg py-2 px-3 font-medium tracking-wide hover:scale-105 hover:!text-black text-white transition">Login
        /
        Signup`;
  }
};

const showProfile = () => {
  document.getElementById("profile").toggleAttribute("data-active");
};

const logout = () => {
  document.cookie = "valid=false";
  window.location.reload();
};

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const response = await fetch("/login", {
    method: "post",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email: email, password: password }),
  });
  if (response.status === 200) {
    document.cookie = `auth=${email}`;
    document.cookie = `valid=true`;
    window.location.reload();
    return;
  }
  const body = await response.text();
  alert(body);
});

document.getElementById("signupForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  console.log(email, password, confirmPassword);
  if (password !== confirmPassword) {
    alert("Password and Confirm Password doesn't match");
    return;
  }
  const response = await fetch("/signup", {
    method: "post",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email: email, password: password }),
  });
  const body = await response.text();
  alert(body);
});

window.addEventListener("click", (e) => {
  if (e.target.id === "auth") {
    showAuth();
  }
});
