const express = require("express");
const app = express();
const reload = require("reload");
const { MongoClient } = require("mongodb");
const client = new MongoClient("mongodb://0.0.0.0:27017");
const crypto = require("crypto");

app.use(express.static("public"));
app.use(express.json());

app.post("/signup", async (req, res) => {
  const userReq = req.body;
  const usersCollection = client.db("hungry").collection("users");
  const user = await usersCollection.findOne({ email: userReq["email"] });
  if (user === null) {
    await usersCollection.insertOne({
      email: userReq["email"],
      password: crypto
        .createHash("sha512")
        .update(userReq["password"])
        .digest("hex"),
    });
    res.status(200).end("Account registered successfully");
  } else {
    res.status(403).end("Account is already successfully");
  }
  res.end();
});

app.post("/login", async (req, res) => {
  const userReq = req.body;
  const usersCollection = client.db("hungry").collection("users");
  console.log(userReq);
  const user = await usersCollection.findOne({
    email: userReq["email"],
    password: crypto
      .createHash("sha512")
      .update(userReq["password"])
      .digest("hex"),
  });
  if (user !== null) {
    res.status(200).end("Welcome");
  } else {
    res.status(403).end("Account is not registered");
  }
  res.end();
});

app.listen(8000, () => {
  console.log("Server runnning on port 8000");
});

reload(app);
